<?php

namespace Magneto\Inquiry\Block\Adminhtml;

class Items extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'index';
        $this->_headerText = __('Items');
        $this->_addButtonLabel = __('Add New Product Inquiry');
        parent::_construct();
    }
}
