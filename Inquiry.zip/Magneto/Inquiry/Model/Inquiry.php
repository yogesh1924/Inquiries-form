<?php
/**
 * Class Inquiry
 *
 *
 * @author      Magneto Team
 * @copyright   Magneto IT Solutions
 * @package     Magneto_Inquiry
 * */
namespace Magneto\Inquiry\Model;

class Inquiry extends \Magento\Framework\Model\AbstractModel
{
    public const CACHE_TAG = 'custom_product_inquiry_post';

    /**
     * @var string
     */
    protected $_cacheTag = 'custom_product_inquiry_post';
    /**
     * @var string
     */
    protected $_eventPrefix = 'custom_product_inquiry_post';

    /**
     * Inquiry Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Magneto\Inquiry\Model\ResourceModel\Inquiry::class);
    }
}
