<?php
/**
 * Class Inquiry
 *
 *
 * @author      Magneto Team
 * @copyright   Magneto IT Solutions
 * @package     Magneto_Inquiry
 */
namespace Magneto\Inquiry\Model\ResourceModel;

class Inquiry extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define Maintable and primarykey
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('product_inquiry', 'entity_id');
    }
}
