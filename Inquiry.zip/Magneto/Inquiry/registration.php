<?php
/**
 *
 * @author      Magneto Team
 * @copyright   Magneto IT Solutions
 * @package     Magneto_Inquiry
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magneto_Inquiry',
    __DIR__
);
