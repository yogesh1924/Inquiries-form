<?php

namespace Magneto\Inquiry\Controller\Adminhtml\Index;

class Add extends \Magento\Backend\App\Action
{
    public function execute()
    {
        $this->_forward('edit');
    }
}
