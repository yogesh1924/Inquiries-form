<?php
/**
 * Class Data
 *
 *
 * @author      Magneto Team
 * @copyright   Magneto IT Solutions
 * @package     Magneto_Inquiry
 */

namespace Magneto\Inquiry\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Get system configuration value
     *
     * @param string $configPath
     * @return mixed
     */
    public function getConfig($configPath)
    {
        return $this->scopeConfig->getValue(
            $configPath,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get product inquiry enabled or not from system configuration
     *
     * @return mixed
     */
    public function getInquiryEnabledGlobally()
    {
        return $this->getConfig('product_inquiry/general/enable');
    }

    /**
     * Get product inquiry title from system configuration
     *
     * @return mixed
     */
    public function getInquiryTitleGlobally()
    {
        return $this->getConfig('product_inquiry/general/label');
    }
}
